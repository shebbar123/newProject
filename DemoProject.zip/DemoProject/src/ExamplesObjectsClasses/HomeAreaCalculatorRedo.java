package ExamplesObjectsClasses;

import java.util.Scanner;

public class HomeAreaCalculatorRedo {
	
	Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HomeAreaCalculatorRedo calculator = new HomeAreaCalculatorRedo();
		Rectangle kichten = calculator.getRoom();
		Rectangle bathroom = calculator.getRoom();
		
		int area = calculator.calculateTotalArea(kichten,bathroom);
		System.out.println("Total area :"+area);
		calculator.input.close();

		
	}
		
		public Rectangle getRoom()
		
		{
			System.out.println("Enter your room length");
			 int length = input.nextInt();
			 
			 System.out.println("Enter your room Width");
			 int width = input.nextInt();
			 
			return new Rectangle(length, width);
			
		}
		
		public int calculateTotalArea(Rectangle rectangle1,Rectangle rectangle2 )
		
		{
			return rectangle1.calculateArea() + rectangle2.calculateArea();
		}
	    

	}


