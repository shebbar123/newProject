package ExamplesObjectsClasses;

public class Rectangle {
	
	private int length;
	private int  width;
	
	public Rectangle()
	{
		length = 0;
		width = 0;
	}
	
	public Rectangle (int length, int width)
	
	{
		this.length =  length;
		setWidth(width);
		
	}
	
	public int getLength()
	
	{
		return length;
	}
	
	public int getWidth()
	
	{
		return width;
	}
	public int setLength(int length)
	
	{
		this.length = length;
		return length;
	}
	
	public int setWidth(int width)
	
	{
	 this.width = width;
	 return width;
	 
	}

	
	public int calculatePerimter ()
	{
		return (2*length)+(2*width);
	}
	
	public int calculateArea ()
	{
		return (length*width);
	}
}
