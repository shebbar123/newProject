package ExamplesObjectsClasses;

public class HomeAreaCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Rectangle room1 = new Rectangle();
		
		room1.setLength(20);
		room1.setWidth(90);
		int l= room1.getLength();
		int w =	room1.getWidth();	
		int areaRoom1 = room1.calculateArea();
		Rectangle room2 = new Rectangle(70,80);
		
		/*int l1 = room2.getLength();
		int w1 = room2.getWidth();*/
		
		int areaRoom2 = room2.calculateArea();
		
		int Area = areaRoom1+areaRoom2;
		
		System.out.println("Area of Home is:" +Area);
		
		

	}

}
