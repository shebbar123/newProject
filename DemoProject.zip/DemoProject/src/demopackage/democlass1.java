package demopackage;

import java.util.Scanner;

public class democlass1 {
	public static void main (String args[])
	{
		//Get the no of hrs worked
		System.out.println("Enter the no of hours: ");
		Scanner input = new Scanner(System.in);
		int hrs = input.nextInt();

		System.out.println("Enter hourly pay rate: ");
		float money = input.nextFloat();
		
		input.close();
		
		double grossPay = hrs*money;
		
		System.out.println("Gross Pay Is: " + grossPay);
		
		//multiply hrs and pay rate
		
		
		//
	}

}
