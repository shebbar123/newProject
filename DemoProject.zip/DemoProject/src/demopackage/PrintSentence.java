package demopackage;

import java.util.Scanner;

public class PrintSentence {

	public static void main(String[] args) {
		System.out.println("Enter season of the year:  ");
		Scanner input = new Scanner(System.in);
		
		String season = input.next();
		
		System.out.println("Enter whole number: ");
		int number = input.nextInt();
		
		System.out.println("Enter an adjective: ");
		String adjective = input.next();
		
		input.close();

		System.out.println("On a " + adjective + " " +  season + " day, I drink minimum of "+ number + " cups of tea");
		

	}

}
