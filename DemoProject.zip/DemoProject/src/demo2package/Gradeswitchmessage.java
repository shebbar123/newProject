package demo2package;

import java.util.Scanner;

public class Gradeswitchmessage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Enter your grade:");
		Scanner input = new Scanner(System.in);
		String grade = input.next();
		
		input.close();
		
		String message;
		
		switch (grade) {
		case "A":
			message = "Excellent JOB";
			break;
		case "B":
			message = "Great job";
			break;
		case "C":
			message = "Good job";
			break;
		case "D":
			message = "Try harder";
			break;
		case "F":
			message = "oh oh!";
			break;
		default:
			message = "Invalid";
			break;
		}
		
		System.out.println(message);
	}

}
