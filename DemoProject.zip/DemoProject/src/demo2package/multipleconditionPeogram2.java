package demo2package;

import java.util.Scanner;

public class multipleconditionPeogram2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.out.println("Enter your Score:  ");
		Scanner input = new Scanner(System.in);
		int score = input.nextInt();	
		input.close();
		
		if (score>=90)
			System.out.println("Your grade is A+");
		else if (score>=75 && score<90 )
			System.out.println("Your grade is A"); 
		else if (score>=60 && score<75 )
			System.out.println("Your grade is B+"); 
		else if (score>=45 && score<60 )
			System.out.println("Your grade is B");
		else if (score>=30 && score<45 )
			System.out.println("Your grade is C");
		else
			System.out.println("You have failed");
		
	}	
	}


