package demo2package;

import java.util.Scanner;

public class SumOfTwoNums {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		boolean again;
		
		do
		{
			System.out.println("Enter no1: ");
			int num1 = input.nextInt();
			System.out.println("Enter no2: ");
			int num2 = input.nextInt();
			int sum = num1+num2;
			
			System.out.println("sum of two numbers is: "+sum);
			
			System.out.println("Do you want to sum the numbers again: true/false ");
			again = input.nextBoolean();	
			
		}while (again);
		input.close();	
		
	}

}
