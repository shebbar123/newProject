package demo2package;

import java.util.Scanner;

public class ChangeForOneRupee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Enter the change amount you have: ");
		Scanner input = new Scanner(System.in);
		System.out.println("Enter how many 50paise coins: ");
		float Paise50 = input.nextFloat();
		System.out.println("Enter how many 25paise coins: ");
		float Paise25 = input.nextFloat();
		System.out.println("Enter how many 10paise coins: ");
		float Paise10 = input.nextFloat();
		System.out.println("Enter how many 5paise coins: ");
		float Paise5 = input.nextFloat();
		System.out.println("Enter how many 1paise coins: ");
		float Paise1 = input.nextFloat();
		input.close();
		
		double totalRupee1 = (0.5*Paise50) + (0.25*Paise25) + (0.1*Paise10) + (0.05*Paise5) + (0.01*Paise1);
		
		if (totalRupee1==1.00)
			System.out.println("Hurray! You Win!");
		else if (totalRupee1>1.00)
		{
			double extraAmount = totalRupee1 - 1.00;
			System.out.println("You are extra by amount" + extraAmount );
		}
		else
		{
			double shortAmount = 1.00 - totalRupee1;
			System.out.println("You are short by amount" + shortAmount);
		}

	}

}
