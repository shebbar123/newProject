package demo2package;

public class Dog
{

	String name;
	String breed;
	int age;
	String color;
	
	Dog (String name, String breed, int age, String color)
	{	
	this.name = name;
	this.color = color;
	this.age = age;
	this.breed = breed;
	}
	
	public String getname () {
		return name;
	}
	public String getbreed () {
		return breed;
	}
	
	public int getage ()
	{
		return age;
	}
	
	public String getcolor()
	{
		return color;
	}
}


