package demo2package;

import java.util.Scanner;

public class MultipleConditionProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        int salary = 30000;
        int numberOfYear = 2;
		
		System.out.println("Your Salary:  ");
		Scanner input = new Scanner(System.in);
		int actualSalary = input.nextInt();
		
		System.out.println("Working Years:  ");
		int actualWorkingYears= input.nextInt();
		
		input.close();
		
		if (actualSalary>=salary && actualWorkingYears>=numberOfYear )
		{
			System.out.println("You are eligible for loan!");
		}
		else 
			System.out.println("You are not eligible for loan");
	}

}
