package demo2package;

import java.util.Scanner;

public class TwoconditionProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int salecondition = 10;
		
		System.out.println("Enter number of sales:  ");
		Scanner input = new Scanner(System.in);
		int sales = input.nextInt();
		input.close();
		
		if (sales >= salecondition )
		
		{System.out.println("Congratulations!");
		}
		else {
			int salesShort = salecondition - sales;
		System.out.println("you are short by " + salesShort);
		}

	}
}
