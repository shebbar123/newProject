package demo2package;

import java.util.Scanner;

public class ConditionalPrograms {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int salary = 1000;
		int salecondition = 10;
		int bonus = 250;
		
		System.out.println("Enter number of sales:  ");
		Scanner input = new Scanner(System.in);
		int sales = input.nextInt();
		input.close();
		
		if (sales > salecondition )
		
		{salary = salary+ bonus;
		}
		
		System.out.println("Your salary is Salary: " + salary );

	}

}
