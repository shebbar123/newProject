package demo2package;

import java.util.Scanner;

public class cashier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double total = 0;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter quantity: ");
		int quantity = input.nextInt();
		
		for (int i=0;i<quantity;i++)
		{
			System.out.println("Enter cost of item: ");
			double cost = input.nextDouble();
		    total = cost+total;
			}
		System.out.println("Total bill is:" +total);
		
	}

}
