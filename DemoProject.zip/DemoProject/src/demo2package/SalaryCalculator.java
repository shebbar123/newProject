package demo2package;

import java.util.Scanner;

public class SalaryCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter no of days employee has worked: ");
		int hrs = input.nextInt();
		
		int rate = 15;
		int noOfhrs = 40;
		
		while (hrs>noOfhrs)
		{
			System.out.println("Enter valid work hrs thats btw 1 to 40: ");
			hrs = input.nextInt();
		}
		double salary = hrs *rate;
		System.out.println("Salary :"+salary);
		
		input.close();
	}

}
