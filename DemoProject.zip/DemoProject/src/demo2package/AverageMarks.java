package demo2package;

import java.util.Scanner;

public class AverageMarks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in);
		
		
		int numberOfTests = 4;
		
		
		for (int i=1;i<=3;i++)
		{
			double total = 0;
			System.out.println("Student #"+ i);
			for (int j=1; j<=4; j++)
			{
				
				System.out.println("Enter the Marks Subject #"+ j);
				double score = input.nextDouble();
				total = score+total;
			}
			double avg = total/numberOfTests;		
			System.out.println("Average of Student #"+ i + " is " + avg);
			input.close();
			
		}
		

	}

}
