package demo2package;

import java.util.Random;

public class DieRoll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int travelSpace=20;
		int limit=5;
		int progress = 0;
		int pendingProgress = 1;
	 
	
		 //Scanner input= new Scanner (System.in);
		 //input.next();
			 for(int i=1;i<=limit;i++)
			 {
		 System.out.println("Roll the die:");
		 Random r = new Random();
		 int die = r.nextInt(6)+1; 
		 
		 
		 System.out.println("Print die:" + die);
		 
		 progress = die + progress;
		 System.out.println("You have progressed: "+progress);
	 
		 if (progress>travelSpace)
		 {
			 System.out.println("You crossed 20 spaces. Try again");
			 break;
		 }
			 
		 else if (progress==travelSpace)
	 {
		 System.out.println("You WON! Congratulations!!!");
		 break;
	 }
	 
	 else
	 {
		 System.out.println("You Lost. Better luck next time");
		 
	 }
		 
		 pendingProgress = travelSpace - progress;
		 System.out.println("You have left "+ pendingProgress + " to make progress");
		
	}

	}
}
	

