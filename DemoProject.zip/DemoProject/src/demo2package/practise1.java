package demo2package;

public class practise1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Dog g = new Dog("Zimba","Poodle", 2, "white");
		System.out.println(g.getname());
		System.out.println(g.getbreed());
		System.out.println(g.getage());
		System.out.println(g.getcolor());

	}

}