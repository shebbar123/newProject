package demo2package;

public class findNumInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = {90, 78, 65, 99, 56, 43, 12};
		
		int num = 78;
		
		boolean isArray = false;
		
		for (int i=0; i< arr.length; i++)
		{
			if (num == arr[i])
			{
				isArray = true;
				break;
				}
		}
		if(isArray)
			System.out.print("Number found");
			else 
			{
				System.out.print("Number not found ");
			}
			}
		
		
	}


