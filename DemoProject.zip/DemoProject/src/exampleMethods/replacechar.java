package exampleMethods;

public class replacechar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name = "sneha";
		String replacedName = name.replace('h', 'b');	
		System.out.println(replacedName);

	}

}
