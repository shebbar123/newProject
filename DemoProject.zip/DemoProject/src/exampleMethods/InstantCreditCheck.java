package exampleMethods;

import java.util.Scanner;

public class InstantCreditCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int salary = 25000;
        int creditScore = 700;
        
        Scanner input = new Scanner(System.in);
        System.out.println("Enter check amount:");
        int checkAmount = input.nextInt(); 
        
        System.out.println("Enter check creditScore:");
        int cS = input.nextInt(); 
        
        if (checkAmount>=salary && cS>=creditScore)
        {
        	System.out.println("You are selected");
        }
        else
        {
        	System.out.println("Rejected");
        }
        
        input.close();
        	
        
        
	}

}
