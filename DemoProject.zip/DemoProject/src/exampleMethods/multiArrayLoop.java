package exampleMethods;

public class multiArrayLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int multiarray [][] = {{10, 15}, {56, 90, 70, 2}};
		
		for (int i=0; i<multiarray.length; i++)
		{
			for (int j=0; j<multiarray[i].length;j++)
				System.out.println(multiarray[i][j]);
		}					
	
}
}
