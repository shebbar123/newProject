package exampleMethods;

public class lotteryPick {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int[] lottoTicket = new int[6];
		
		String[] cars = {"Maruthi", "Swift", "Honda", "XRN" };
		/*for (int i=0; i<cars.length;i++)
		{
			System.out.println(cars[i]);
		}*/
		
		for (String i : cars) {
			  System.out.println(i);}
		
	}
	

}
