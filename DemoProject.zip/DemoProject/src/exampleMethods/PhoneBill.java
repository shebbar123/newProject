package exampleMethods;

import java.util.Scanner;

public class PhoneBill {
	
	private int id;
	private double baseCost;
	private double allotedMinutes;
	private double noOfMinutesUsed;
	private Scanner scanner = new Scanner(System.in);


	public PhoneBill ()
	{
		id = 0;
		baseCost = 0;
		allotedMinutes=0;
		noOfMinutesUsed=0;
	}
	
	public PhoneBill (int id)
	
	{
		 this.id = id;
		 baseCost = 0;
		 allotedMinutes=0;
		 noOfMinutesUsed=0;
	}
	
public PhoneBill (int id, double baseCost, double allotedMinutes, double noOfMinutesUsed)
	
	{
		 this.id = id;
		 this.baseCost = baseCost;
		 this.allotedMinutes = allotedMinutes;
		 this.noOfMinutesUsed = noOfMinutesUsed;
		
	}

public double calculateOverages(double extraMinutes){
    double rate = 0.25;
    double overage = extraMinutes * rate;
    return overage;
}

public double calculateTax(double subtotal){
    double rate = 0.15;
    double tax = subtotal * rate;
    return tax;
}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PhoneBill phbill1 = new PhoneBill();
		PhoneBill phbill2 = new PhoneBill(5);
		PhoneBill phbill3 = new PhoneBill(10,1.5,30.5,5.5);
		
		
		
		
		double Overage = phbill3.calculateOverages(10);
		System.out.println("Overage: " +Overage);
		
		double Tax = 
		

	}

}
