package exampleMethods;

public class reverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int reverse = 0;
		int remainder =0;
		int num = 123;
		
		while (num>0)
		{
			remainder = num%10; 
			reverse = (reverse*10)+remainder; 
			num = num/10; 
		}

		System.out.println(reverse);
		}

}
