package exampleMethods;

public class reverseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arr [] = {90, 80, 56, 21};
		
		int l = arr.length;
			
		for (int i=0; i<(arr.length/2) ; i++)
			
		{	
			int temp = arr[i];
			arr[i] = arr[l-i-1];
			arr[l-i-1] = temp;
			
			
		}
		
		for (int element : arr)
		System.out.print( element + " ");
		
		
		

	}

}
