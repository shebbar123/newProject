package exampleMethods;

public class reverseHalfString {
    public static void main (String[] args) {
      
    String str= "Sneha1234"; String  revStr="";
    char ch;
      
    for (int i=0; i<=4; i++)
      {
        ch= str.charAt(i); 
        revStr= ch+revStr; 
      }
    System.out.println("Reversed word: "+ revStr + "1234");
    }
}
