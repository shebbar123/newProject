package exampleMethods;

public class reverseand {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name = "sne$&&$ha$&$$**"; // //ah$&&$ens$&$$
		char ch=0;
		String revStr="";
		
		
		for (int i=0; i<name.length(); i++)
			//for (int i=name.length()-1; i>=0; i--)
	      {
			if (Character.isLetter(name.charAt(i)))
			{
				//System.out.println("char checked now:" +name.charAt(i));
				//System.out.println("Inside if condition");
	        ch= name.charAt(i); 
	        revStr= ch+revStr; 
	     
			}
			else
			{
				ch = name.charAt(i);
				revStr= revStr+ch;		
			}		  
	      }
		
		System.out.println(revStr);  
	}

}
