package exampleMethods;


public class Empexample {
	
	static String employeeName;
	static double employeeSalary;
	
public void set (String n, double s)

{
	employeeName = n;
	employeeSalary = s;
	}
	
public void get ()
{
System.out.println("Employee Name is" +employeeName);	
System.out.println("employee Salary Is:" +employeeSalary);	
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	 Empexample e =new Empexample();
	 e.set("Sneha", 2500.87);
	 e.get();
	}

}
