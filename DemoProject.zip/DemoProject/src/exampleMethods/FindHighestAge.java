package exampleMethods;

public class FindHighestAge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int  numbers[] = {67,80,9,1,100,3};
		int highestAge = numbers[0];
		
		for(int i = 0; i< numbers.length; i++)
		{
			if (highestAge < numbers[i])
			{
				highestAge = numbers[i];
			}
				
		}
		
		System.out.println("Max Age is: " +highestAge);
		
		

	}

}
