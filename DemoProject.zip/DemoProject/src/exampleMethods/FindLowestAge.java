package exampleMethods;

public class FindLowestAge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int  numbers[] = {67,80,9,1,12,3};
		int lowest = numbers[0];
		
		for(int i = 0; i< numbers.length; i++)
		{
			if (lowest > numbers[i])
			{
				lowest = numbers[i];
			}
				
		}
		
		System.out.println("Min number is: " +lowest);
		
		

	}

}
