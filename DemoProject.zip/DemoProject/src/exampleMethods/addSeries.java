package exampleMethods;

public class addSeries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int total = 0;
		int num = 1234321;
		int rem= 0;
		
		int sumfirst3digits = 0;
		int sumlast3digits = 0;
		
		int Quotient1 = num/1000000; 
		rem = num%1000000;
		//System.out.println(Quotient1);
		//System.out.println(rem);
		
		int Quotient2= rem/100000;
		rem = rem%100000;
		//System.out.println(Quotient2);
		//System.out.println(rem);
		
		int Quotient3= rem/10000;
		rem = rem%10000;
		//System.out.println(Quotient3);
		//System.out.println(rem);
	
		sumfirst3digits =  Quotient1 + Quotient2+  Quotient3;
        System.out.println("Sum Of first 3 digits :" +sumfirst3digits);
		
		
		while (num>=12340)
		{
			rem = num%10; 
			sumlast3digits =sumlast3digits +rem; 
			num = num/10; 
		}
		System.out.println("Sum Of last 3 digits :" +sumlast3digits); 
		
		
		total = sumfirst3digits+sumlast3digits;
		
		
		System.out.println("Total Sum:" + total);
		
		
	}
}
