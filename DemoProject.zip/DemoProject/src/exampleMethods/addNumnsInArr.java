package exampleMethods;

public class addNumnsInArr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int val[] = {1,2,3,4,5,6,7,7,89};
		int sum = 0;
		for (int i = 0; i< val.length; i++ )
		{
		if( (val[i] >5) && (val[i] < 90))
			sum = sum + val[i];
		}
		System.out.println(sum);

	}

}
