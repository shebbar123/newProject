package exampleMethods;

import java.util.Scanner;

public class phoneBillCalculator {
	
	static Scanner input = new Scanner (System.in);
	static double overageFee = 0.25;
	static double taxPercent= 0.15;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter base plan amount:");
		double baseCostOfPlan = input.nextDouble();
		
		System.out.println("Base cost plan amount is: " +baseCostOfPlan);
		
	
		double subTotal= calculateSubTotal();
		System.out.println("Overage: " +subTotal);
		
		double taxAmount=calculateTAX(baseCostOfPlan);
		System.out.println("TAX: " +taxAmount);
		
		double totalBill = calculateTotalBill(subTotal,taxAmount);
		System.out.println("Total Bill: " +totalBill);
		
	}
		
		public static double calculateSubTotal()
		
		{
			System.out.println("Enter overage minutes:");
			int overageMinutes = input.nextInt();
			double subTotal = overageMinutes*overageFee;
			return subTotal;
		}
		
		public static double calculateTAX(double baseCostOfPlan)
		{
			double taxAmount = taxPercent*baseCostOfPlan;
			 return taxAmount;
		}
		public static double calculateTotalBill(double subTotal, double taxAmount)
		{
			double totalBill = subTotal+taxAmount;
			return  totalBill;
		}
		
}


